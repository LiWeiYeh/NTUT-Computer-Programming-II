// quicksort.h

#ifndef QUICKSORT_H
#define QUICKSORT_H

// sorting algortihm for an interger array
void quicksort(int a[], int low, int high);

#endif